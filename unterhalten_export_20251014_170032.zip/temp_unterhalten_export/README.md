# UnterhaltenView Export - Tue Oct 14 17:00:15 CEST 2025

## Enthaltene Dateien:

### Communication/UnterhaltenView:
- src/features/communication/ - Komplette Communication-Feature
- src/features/communication/views/UnterhaltenView.vue - Hauptkomponente
- src/features/communication/views/UnterhaltenView.ts - TypeScript Logic
- src/features/communication/views/UnterhaltenView.css - Styling
- src/features/communication/composables/useVirtualKeyboardIntegration.ts - Virtual Keyboard Integration
- src/features/communication/composables/useVirtualKeyboard.ts - Legacy Virtual Keyboard
- src/features/communication/components/KeyboardDesign.vue - Keyboard UI
- src/features/communication/services/KeyboardDesignService.ts - Keyboard Service
- src/features/communication/stores/communication.ts - Communication Store
- src/features/communication/stores/keyboardDesign.ts - Keyboard Design Store

### Face Recognition/Eye Detection:
- src/features/face-recognition/ - Komplette Face Recognition Feature
- src/features/face-recognition/composables/useFaceRecognition.ts - Face Recognition Composable
- src/features/face-recognition/services/FaceRecognitionService.ts - Face Recognition Service

### TTS (Text-to-Speech):
- src/core/application/SimpleFlowController.ts - Haupt-TTS-Controller
- src/config/ttsConfig.ts - TTS-Konfiguration
- src/config/virtualKeyboardConfig.ts - Virtual Keyboard Konfiguration
- src/config/virtualKeyboardStateMachine.ts - Virtual Keyboard State Machine

### Types:
- src/types/ - TypeScript Typen
- src/shared/types/ - Shared TypeScript Typen

### Navigation:
- src/features/navigation/views/HomeView.ts - Home View (für Navigation)

## Wichtige Änderungen:
- Doppelte TTS-Aufrufe für Zeilen behoben
- TTS-Synchronisation zwischen Begrüßung und Virtual Keyboard verbessert
- 2-Sekunden-Pause zwischen Zeilen-Ansage und Buchstaben-Scanning implementiert
- TTS-Queue-Management optimiert
- Face Recognition Integration verbessert

