/**
 * UnterhaltenView JavaScript Logic
 * Virtuelle Tastatur für Kommunikation mit State-Machine
 */

import { ref, onMounted, onUnmounted, computed } from 'vue'

// TypeScript declaration for window property
declare global {
  interface Window {
    ttsIntroAbgespielt?: boolean
  }
}
import { useRouter } from 'vue-router'
import { useSettingsStore } from '../../settings/stores/settings'
import { useKeyboardDesignStore } from '../stores/keyboardDesign'
import { useVirtualKeyboardIntegration } from '../composables/useVirtualKeyboardIntegration'
import { simpleFlowController } from '../../../core/application/SimpleFlowController'

// Export function to be called from Vue component
export function useUnterhaltenViewLogic() {
  // Router
  const router = useRouter()

  // Stores
  const settingsStore = useSettingsStore()
  const keyboardDesignStore = useKeyboardDesignStore()

  // Virtuelle Tastatur Integration
  const {
    currentText,
    currentState,
    activeRowIndex,
    activeLetterIndex,
    isTTSActive,
    showCurrentText,
    keyboardLayout,
    isRowActive,
    isLetterActive,
    isRowSelected,
    isLetterSelected,
    initializeVirtualKeyboard,
    stopVirtualKeyboard,
    resetIntroStatus,
    handleClick,
    clearText,
    readCurrentText,
    isRowHighlighted,
    isLetterHighlighted,
    isRowSelectedState,
    getRowClass,
    getLetterClass,
    getTTSIndicatorClass,
    faceRecognition
  } = useVirtualKeyboardIntegration()

  // Legacy compatibility - mapped to new system
  const selectedText = currentText
  const currentRowIndex = activeRowIndex
  const currentLetterIndex = activeLetterIndex
  const isKeyboardActive = computed(() => currentState.value !== 'idle')
  const currentStage = computed(() => {
    if (isRowActive.value) return 'rows'
    if (isLetterActive.value) return 'letters'
    return 'idle'
  })

  // Legacy functions for compatibility
  const handleBlink = () => {
    handleClick()
  }

  // Face Blinzel-Handler für globale Face Recognition
  const handleFaceBlink = (event: any) => {
    console.log('UnterhaltenView: Face blink received:', event.detail)
    handleClick()
  }

  const startKeyboard = () => {
    initializeVirtualKeyboard()
  }

  const stopKeyboard = () => {
    stopVirtualKeyboard()
  }

  const isCurrentRow = (rowIndex: number) => {
    return isRowHighlighted(rowIndex)
  }

  const isCurrentLetter = (letter: string, rowIndex: number) => {
    return isLetterHighlighted(rowIndex, activeLetterIndex.value)
  }

  const selectCurrentElement = () => {
    handleClick()
  }

  const testFunction = () => {
    console.log('Test button clicked!')
    currentText.value += 'TEST '
  }

  const startKeyboardNavigation = () => {
    // Navigation wird automatisch von der State-Machine gesteuert
    console.log('Navigation is handled by State-Machine')
  }

  // Event Listeners
  onMounted(async () => {
    console.log('Component mounted, preparing virtual keyboard...')

    // Einführungstext (wird nur einmal pro Sitzung gesprochen)
    const introText = `Willkommen in der virtuellen Tastatur. 
    Blinzeln Sie eine Zeile Ihrer Wahl an. 
    Nachdem Sie eine Zeile ausgewählt haben, 
    laufen die Buchstaben dieser Zeile automatisch durch. 
    Blinzeln Sie erneut, um einen Buchstaben auszuwählen. 
    So können Sie Schritt für Schritt Wörter und Sätze bilden. 
    Die Tastatur läuft in einer Endlosschleife, 
    damit Sie jederzeit weiterschreiben können.`

    // Falls noch nicht abgespielt
    if (!window.ttsIntroAbgespielt) {
      console.log('Starting TTS introduction...')
      try {
        // Registriere TTS-Ende-Listener
        simpleFlowController.onTTSEnd(() => {
          console.log('TTS greeting completed - starting virtual keyboard after 3 second pause...')
          
          // 3 Sekunden Pause nach der Einführung (wie gewünscht)
          setTimeout(() => {
            console.log('Starting virtual keyboard after 3 second pause...')
            initializeVirtualKeyboard()
          }, 3000)
        })

        // Verwende SimpleFlowController für Volume-Toggle-Kompatibilität
        await simpleFlowController.speakForVirtualKeyboard(introText)

        // Markiere als abgespielt
        window.ttsIntroAbgespielt = true

        // TTS-Ende-Listener wird automatisch getriggert wenn TTS fertig ist
        console.log('TTS greeting started - waiting for completion via listener...')
        
      } catch (error) {
        console.warn('TTS introduction failed, starting keyboard anyway.', error)
        // Entferne Listener bei Fehlern
        simpleFlowController.clearTTSEndListeners()
        initializeVirtualKeyboard()
      }
    } else {
      // Wenn bereits einmal abgespielt → 3 Sekunden Pause, dann starten
      console.log('Intro already played — waiting 3 seconds before starting keyboard.')
      setTimeout(() => {
        initializeVirtualKeyboard()
      }, 3000)
    }

    // Rechtsklick für manuelle Auswahl
    document.addEventListener('contextmenu', (e) => {
      e.preventDefault()
      console.log('Right click detected')
      handleClick()
    })
  })

  onUnmounted(() => {
    console.log('Component unmounting, stopping all TTS and virtual keyboard...')
    
    // Entferne alle TTS-Ende-Listener
    simpleFlowController.clearTTSEndListeners()
    
    // Stoppe alle laufenden TTS (beide Systeme)
    speechSynthesis.cancel()  // Direkte TTS-Implementierungen
    simpleFlowController.stopTTSOnly()  // SimpleFlowController TTS (ohne Queue zu leeren)
    
    // Stoppe virtuelle Tastatur
    stopVirtualKeyboard()
  })

  // Return all values for Vue component
  return {
    // State (Legacy compatibility)
    closedFrames: ref(0),
    eyesClosed: ref(false),
    blinkThreshold: computed(() => Math.ceil(settingsStore.settings.blinkSensitivity * 10)),
    lastBlinkTime: ref(0),
    blinkCooldown: computed(() => settingsStore.settings.blinkSensitivity * 1000),
    isKeyboardActive,
    keyboardInterval: ref(null),
    selectedText,
    keyboardLayout,
    currentRowIndex,
    currentLetterIndex,
    currentStage,
    letterPassCount: ref(0),
    
    // New virtual keyboard state
    currentText,
    currentState,
    activeRowIndex,
    activeLetterIndex,
    isTTSActive,
    showCurrentText,
    isRowActive,
    isLetterActive,
    isRowSelected,
    isLetterSelected,
    
    // Functions (Legacy compatibility)
    handleBlink,
    handleFaceBlink,
    startKeyboard,
    stopKeyboard,
    isCurrentRow,
    isCurrentLetter,
    selectCurrentElement,
    testFunction,
    startKeyboardNavigation,
    
    // New virtual keyboard functions
    initializeVirtualKeyboard,
    stopVirtualKeyboard,
    handleClick,
    clearText,
    readCurrentText,
    resetIntroStatus,
    isRowHighlighted,
    isLetterHighlighted,
    isRowSelectedState,
    getRowClass,
    getLetterClass,
    getTTSIndicatorClass,
    
    // Stores
    settingsStore,
    keyboardDesignStore,
    faceRecognition
  }
}