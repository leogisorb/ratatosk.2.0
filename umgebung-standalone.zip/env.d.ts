/// <reference types="vite/client" />

// Global window properties
declare global {
  interface Window {
    ttsIntroAbgespielt?: boolean
  }
}
