import { createApp } from 'vue'
import { createPinia } from 'pinia'
import { createRouter, createWebHistory } from 'vue-router'
import App from './App.vue'
import ErnaehrungView from './features/nutrition/views/ErnaehrungView.vue'

// Import global CSS
import './assets/main.css'

// Router setup
const router = createRouter({
  history: createWebHistory(),
  routes: [
    {
      path: '/',
      redirect: '/ernaehrung'
    },
    {
      path: '/ernaehrung',
      component: ErnaehrungView
    }
  ]
})

// Create app
const app = createApp(App)
const pinia = createPinia()

app.use(pinia)
app.use(router)

app.mount('#app')
